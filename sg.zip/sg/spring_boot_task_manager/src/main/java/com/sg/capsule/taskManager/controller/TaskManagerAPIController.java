/**
 * 
 */
package com.sg.capsule.taskManager.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sg.capsule.taskManager.dto.Task;
import com.sg.capsule.taskManager.service.ITaskManagerService;


/**
 * @author RM
 *
 */

@RestController
@RequestMapping("/tasks")
@CrossOrigin(origins = {"http://localhost:4200"})
public class TaskManagerAPIController {
	
	final static Logger logger = Logger.getLogger(TaskManagerAPIController.class.getName());

	@Autowired
	private ITaskManagerService taskManagerService;
	
	@CrossOrigin(origins = {"http://localhost:4200"})
	@GetMapping(value="/",  produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Task>> getAllTasks() {
		logger.info("Enter TaskManagerAPIController - getAllTasks()");
		ResponseEntity<List<Task>> result = null;
		
		List<Task> taskList = taskManagerService.getAllTasks();
				
		if(taskList != null) {
			logger.debug("Task list size :: " + taskList.size());
			result = new ResponseEntity<List<Task>>(taskList, HttpStatus.OK);
		}else {
			result = new ResponseEntity<List<Task>>(taskList, HttpStatus.NOT_FOUND);
		}
		
		logger.info("Exit TaskManagerAPIController - getAllTasks()");
		return result;
		
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"})
	@RequestMapping(value = "/{taskId}", method = RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Task> getTask(@PathVariable("taskId") Long taskId) {
		logger.info("Enter TaskManagerAPIController - getTask()");
		ResponseEntity<Task> result = null;
		
		Task task = taskManagerService.getTaskByID(taskId);
		
		if(task != null) {
			result = new ResponseEntity<Task>(task, HttpStatus.OK);
		}else {
			result = new ResponseEntity<Task>(task, HttpStatus.NOT_FOUND);
		}
		
		logger.info("Exit TaskManagerAPIController - getTask()");
		return result;
		
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"})
	@PostMapping(value = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> saveTask(@Valid @RequestBody Task task) {
		logger.info("Enter TaskManagerAPIController - saveTask()");

		boolean saveSuccessFlag = false;
		ResponseEntity<Void> result = null;
		
		if(task != null) {
			logger.info("Incoming Task :: " + task);
			logger.debug("Task ID :: " + task.getTaskId());
			logger.debug("Task Name :: " + task.getTaskName());
			logger.debug("Parent Task ID :: " + task.getParentTask());
			saveSuccessFlag = taskManagerService.saveTask(task);
		}
		
		if(saveSuccessFlag) {
			logger.info("Task successfully created...");
			result = new ResponseEntity<Void>(HttpStatus.CREATED);
		}else {
			logger.debug("Failed to save Task...");
			result = new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}

		logger.info("Exit TaskManagerAPIController - getTask()");
		return result;
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"})
	@PutMapping("/{taskId}" )
	public ResponseEntity<Task> updateTask(@PathVariable Long taskId, @RequestBody Task task) {
		logger.info("Enter TaskManagerAPIController - updateTask()");
		boolean updateFlag = false;
		ResponseEntity<Task> result = null;
		
		if(task != null) {
			updateFlag = taskManagerService.updateTask(task);
		}
		
		if(updateFlag) {
			result =  new ResponseEntity<Task>(task, HttpStatus.OK);
		}else {
			result =  new ResponseEntity<Task>(task, HttpStatus.NOT_FOUND);
		}
		
		logger.info("Exit TaskManagerAPIController - updateTask()");
		return result;
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"})
	@DeleteMapping("/{taskId}")
	public ResponseEntity<Void> deleteTask(@PathVariable("taskId") Long taskId) {
		logger.info("Enter TaskManagerAPIController - deleteTask()");
		boolean deleteFlag = false;
		ResponseEntity<Void> result = null;
		
		if(taskId != null) {
			deleteFlag = taskManagerService.deleteTask(taskId);
		}
		
		if(deleteFlag) {
			result =  new ResponseEntity(taskId, HttpStatus.GONE);
		}else {
			result =  new ResponseEntity(taskId, HttpStatus.NOT_FOUND);
		}
		
		logger.info("Exit TaskManagerAPIController - deleteTask()");
		return result;

	}
}
